package com.softeng.ooyoo.databases

class LocalStorage {

    public fun retrievePhoneFiles(): Any{

        return Any()
    }

}