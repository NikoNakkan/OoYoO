package com.softeng.ooyoo.travel

import com.softeng.ooyoo.user.User

class UserAndTravelEvent(val user: User, val travelEvent: com.softeng.ooyoo.travel.TravelEvent)