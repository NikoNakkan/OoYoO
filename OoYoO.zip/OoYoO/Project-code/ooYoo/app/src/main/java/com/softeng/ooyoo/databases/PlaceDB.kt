package com.softeng.ooyoo.databases

import com.softeng.ooyoo.place.Place

class PlaceDB: Database(PLACES) {

    public fun retrievePlaces(placeId: String): ArrayList<Place>{

        return arrayListOf()
    }

}