package com.softeng.ooyoo.mainScreens

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.softeng.ooyoo.R

class AddHomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_home)
    }
}
