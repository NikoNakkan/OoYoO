package com.softeng.ooyoo.databases

abstract class Database(protected val collection: String)