# OoYoO
Software Engineering Project
Read Project-description.pdf for description.

Founders: 
Georgopoulos-Ninos Nikolaos,
Nakkas Nikolaos,
Papakos Miltiadis,
Syrokostas Konstantinos.
